document.addEventListener("DOMContentLoaded", function () {
    const svgImages = [
        'assets/ethereum-eth.svg',
        'assets/usd.svg',
        'assets/bitcoin.svg',
        'assets/USDT.svg',
        'assets/solana.svg',
        'assets/dot.svg',
        'assets/shib.svg',
        'assets/ada.svg',
        'assets/ton.svg',
        'assets/trx.svg',
        'assets/ltc.svg',
        'assets/bch.svg',
        'assets/bnb.svg',
        'assets/usdc.svg',
        'assets/xrp.svg',
        'assets/doge.svg',
        'assets/gold.svg',
        'assets/dollars4.svg',
        'assets/dollars1.svg',
        'assets/dollar1.svg',
        'assets/dollars2.svg',
        'assets/dollar3.svg'
    ];

    const container = document.getElementById('randomImagesContainer');
    const placedImages = []; 

    function checkOverlap(newPosition, imageSize) {
        for (let i = 0; i < placedImages.length; i++) {
            const existing = placedImages[i];

            
            const overlapX = newPosition.x < existing.x + imageSize.width && newPosition.x + imageSize.width > existing.x;
            const overlapY = newPosition.y < existing.y + imageSize.height && newPosition.y + imageSize.height > existing.y;

            if (overlapX && overlapY) {
                return true; 
            }
        }
        return false; 
    }

    function getRandomPosition(side, imageSize) {
        const viewportHeight = window.innerHeight;
        const randomY = Math.floor(Math.random() * (viewportHeight - imageSize.height));

        let randomX;
        if (side === 'left') {
            randomX = Math.floor(Math.random() * 300); 
        } else { 
            randomX = window.innerWidth - Math.floor(Math.random() * 300) - 150; 
        }

        return { x: randomX, y: randomY };
    }

    svgImages.forEach((imgPath) => {
        const img = document.createElement('img');
        img.src = imgPath;
        img.alt = 'Random SVG';
        img.classList.add('random-image');
        const imageSize = { width: 100, height: 100 }; 

        let position;
        let tries = 0;
        do {
            
            const side = Math.random() < 0.5 ? 'left' : 'right';
            position = getRandomPosition(side, imageSize);
            tries++;
        } while (checkOverlap(position, imageSize) && tries < 100); 

        
        placedImages.push(position);

        img.style.left = `${position.x}px`;
        img.style.top = `${position.y}px`;

        
        container.appendChild(img);
    });
});

